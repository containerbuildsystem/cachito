from setuptools import setup

setup(
    name="myapp",
    url="http://github.com/cqi/myapp",
    license="MIT",
    description="my app",
    long_description="my app",
    version="0.1",
    author="cqi",
    author_email="cqi@redhat.com",
    py_module=["app"],
    python_requires=">=3.6",
)
